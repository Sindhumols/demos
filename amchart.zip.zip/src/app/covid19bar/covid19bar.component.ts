import { Component,OnInit , Inject, NgZone, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

// amCharts imports
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import { RepotersService } from '../services/repoters.service';

interface location{
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-covid19bar',
  templateUrl: './covid19bar.component.html',
  styleUrls: ['./covid19bar.component.scss']
})


export class Covid19barComponent implements OnInit {
  private chart: am4charts.XYChart;
  data: any;
  response: any = [];
  selectedValue: string;
  country: location[] = [];

  constructor(@Inject(PLATFORM_ID) private platformId,
  private zone: NgZone,
  private service: RepotersService) { }
  onDateClick(event) {
    console.log('Country', event.value);
    this.data.filter(element => {
      if (element["location"] == event.value) {
        this.chart.data = [
          { "sect": "confirmed", "size": element["confirmed"]},
          {"sect": "dead", "size": element["dead"]},
          {"sect": "recovered", "size": element["recovered"]}
        ]; 
      }});
  }

  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }

  ngAfterViewInit() {
    // Chart code goes in here
    this.browserOnly(() => {
      am4core.useTheme(am4themes_animated);

      let chart = am4core.create("chartdiv", am4charts.XYChart);
    //   var  valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    //   valueAxis.title.text = "Cases";
    //   valueAxis.title.fontWeight="bold";

    //   var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    //   categoryAxis.title.text = "Countries";
    //   categoryAxis.title.fontWeight="bold";
    //   categoryAxis.renderer.grid.template.location = 0;
    //   categoryAxis.renderer.minGridDistance = 20;
    //  let arr= categoryAxis.dataFields.category= "location";
            var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      // categoryAxis.dataFields.category = "dead","confirmed","recovered";
       categoryAxis.dataFields.category= "location";
      categoryAxis.title.text = "Countries";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 20;
      
      
      var  valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      valueAxis.title.text = "Cases";
      
      // Create series
      var series = chart.series.push(new am4charts.ColumnSeries());
      series.dataFields.valueY = "dead";
      series.dataFields.categoryX = "location";
      series.name = "dead";
      series.tooltipText = "{name}: [bold]{valueY}[/]";
      series.stacked = true;
      
      var series2 = chart.series.push(new am4charts.ColumnSeries());
      series2.dataFields.valueY = "confirmed";
      series2.dataFields.categoryX = "location";
      series2.name = "confirmed";
      series2.tooltipText = "{name}: [bold]{valueY}[/]";
      series2.stacked = true;
      
      var series3 = chart.series.push(new am4charts.ColumnSeries());
      series3.dataFields.valueY = "recovered";
      series3.dataFields.categoryX = "location";
      series3.name = "recovered";
      series3.tooltipText = "{name}: [bold]{valueY}[/]";
      series3.stacked = true;
      
      // Add cursor
      chart.cursor = new am4charts.XYCursor();
  //     chart.paddingRight = 20;
this.chart=chart;
  //     let data = [];
  //    
    });
  }

  ngOnInit(): void {
   this.getAllReports();
  }
  public getAllReports() {
    this.service.covid19Countryreport().
      subscribe((response) => {
        console.log('response3', response);

        this.chart.data = response["data"];
        console.log('data of country bar', this.data);
        this.data.forEach(element => {
          this.country.push(
            { value: element["location"], viewValue: element["location"] }
          );
        });
      
        // this.chart.data = [
        //   {
        //     "sect": "confirmed", "size": this.data[0]["confirmed"],
        //   },
        //   {
        //     "sect": "dead", "size": this.data[0]["dead"],
        //   },
        //   {
        //     "sect": "recovered", "size": this.data[0]["recovered"]
        //   }
        // ]

       
        }
        );
}}