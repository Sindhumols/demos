

export interface Countryreport{
    // appName: string;
    // version:string;
    // apiVersion:string;
    // appVersionCode:any;
    // appUpdateurl:string;
    day:string;
    totalSamplesTested: number;
    totalIndividualsTested: number;
    totalPositiveCases: number;
    source: string;
}